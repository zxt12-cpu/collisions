document.addEventListener('DOMContentLoaded', () => {
    // Get canvas and context
    const canvas = document.getElementById('simulationCanvas');
    const ctx = canvas.getContext('2d');
    canvas.width = 800;
    canvas.height = 600;

    // Get stats elements
    const stats = {
        fps: document.getElementById('fps'),
        remainingShapes: document.getElementById('remainingShapes'),
    };

    // Shape Class
    class Shape {
      constructor(x, y, dx, dy, size, color, type, style) {
          this.x = x;
          this.y = y;
          this.dx = dx;
          this.dy = dy;
          this.size = size;
          this.color = color;
          this.type = type; // 'circle' or 'rectangle'
          this.style = style; // Style object for custom draw behavior
          this.collisions = 0;
        }
       draw() {
          if (this.style.draw) {
             this.style.draw(ctx, this);
           }
      }


      move() {
          this.x += this.dx;
          this.y += this.dy;

          if (this.x <= 0 || this.x >= canvas.width - this.size * (this.type === 'rectangle'? 2 : 1)) this.dx *= -1;
          if (this.y <= 0 || this.y >= canvas.height - this.size) this.dy *= -1;
       }

      checkCollision(other) {
         if (this.type === 'circle' && other.type === 'circle') {
           const dist = Math.hypot(this.x - other.x, this.y - other.y);
              return dist < this.size + other.size;
          } else if (this.type === 'rectangle' && other.type === 'rectangle') {
              return (
                this.x < other.x + other.size * 2 &&
                  this.x + this.size * 2 > other.x &&
                this.y < other.y + other.size &&
                this.y + this.size > other.y
               );
            } else {
                 const circle = this.type === 'circle'? this : other;
                  const rect = this.type === 'rectangle'? this : other;
                const distX = Math.abs(circle.x - rect.x - rect.size);
               const distY = Math.abs(circle.y - rect.y - rect.size / 2);
                if (distX > rect.size + circle.size || distY > rect.size + circle.size) return false;
               if (distX <= rect.size || distY <= rect.size) return true;
                return (
                 Math.pow(distX - rect.size, 2) + Math.pow(distY - rect.size, 2) <=
                 Math.pow(circle.size, 2)
                  );
            }
        }
    }


    const shapeStyles = {
     'fill': {
            draw: (ctx, shape) => {
              ctx.fillStyle = shape.color;
              if (shape.type === 'circle') {
                 ctx.beginPath();
                 ctx.arc(shape.x, shape.y, shape.size, 0, Math.PI * 2);
                  ctx.closePath();
                   ctx.fill();
                } else if (shape.type === 'rectangle') {
                    ctx.fillRect(shape.x, shape.y, shape.size * 2, shape.size);
                }
            }
       },
       'stroke': {
         draw: (ctx, shape) => {
              ctx.strokeStyle = shape.color;
                ctx.lineWidth = 2;
                if (shape.type === 'circle') {
                  ctx.beginPath();
                   ctx.arc(shape.x, shape.y, shape.size, 0, Math.PI * 2);
                     ctx.closePath();
                     ctx.stroke();
                } else if (shape.type === 'rectangle') {
                     ctx.strokeRect(shape.x, shape.y, shape.size * 2, shape.size);
               }
            }
       },
     'dashed': {
            draw: (ctx, shape) => {
               ctx.strokeStyle = shape.color;
                 ctx.lineWidth = 2;
                 ctx.setLineDash([5, 5]);
                if (shape.type === 'circle') {
                    ctx.beginPath();
                    ctx.arc(shape.x, shape.y, shape.size, 0, Math.PI * 2);
                    ctx.closePath();
                    ctx.stroke();
               } else if (shape.type === 'rectangle') {
                   ctx.strokeRect(shape.x, shape.y, shape.size * 2, shape.size);
               }
               ctx.setLineDash([]); // Reset line dash to default
             }
       },

     'gradient': {
            draw: (ctx, shape) => {
               if (shape.type === 'circle') {
                const gradient = ctx.createRadialGradient(shape.x, shape.y, 0, shape.x, shape.y, shape.size);
                gradient.addColorStop(0, shape.color);
                gradient.addColorStop(1, 'white'); // Inner white
                   ctx.fillStyle = gradient;
                    ctx.beginPath();
                    ctx.arc(shape.x, shape.y, shape.size, 0, Math.PI * 2);
                    ctx.closePath();
                    ctx.fill();
                } else if (shape.type === 'rectangle') {
                   const gradient = ctx.createLinearGradient(shape.x, shape.y, shape.x + shape.size*2, shape.y+shape.size);
                 gradient.addColorStop(0, shape.color);
                 gradient.addColorStop(1, 'white');
                 ctx.fillStyle = gradient;
                    ctx.fillRect(shape.x, shape.y, shape.size * 2, shape.size);
                }
             }
     },

     'textured': {
         draw: (ctx, shape) => {
           const texture = new Image();
               texture.src = 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3a/Cat03.jpg/800px-Cat03.jpg'; // Replace with a texture URL, or load the images
               texture.onload = () => {
                   const pattern = ctx.createPattern(texture, 'repeat');
                  ctx.fillStyle = pattern;
                 if (shape.type === 'circle') {
                         ctx.beginPath();
                        ctx.arc(shape.x, shape.y, shape.size, 0, Math.PI * 2);
                         ctx.closePath();
                       ctx.fill();
                   } else if (shape.type === 'rectangle') {
                     ctx.fillRect(shape.x, shape.y, shape.size * 2, shape.size);
                  }
                }
              if (texture.complete){
                    const pattern = ctx.createPattern(texture, 'repeat');
                     ctx.fillStyle = pattern;
                      if (shape.type === 'circle') {
                        ctx.beginPath();
                           ctx.arc(shape.x, shape.y, shape.size, 0, Math.PI * 2);
                          ctx.closePath();
                        ctx.fill();
                       } else if (shape.type === 'rectangle') {
                        ctx.fillRect(shape.x, shape.y, shape.size * 2, shape.size);
                       }
                 }
             }
       }
    };


    // Array to store all shapes
      const shapes = [];
        const styles = Object.keys(shapeStyles); // Array of available style names
       const types = ['circle', 'rectangle'];

        // Create 50 shapes with random attributes
       for (let i = 0; i < 50; i++) {
         const size = Math.random() * 20 + 10;
            const x = Math.random() * (canvas.width - size * 2);
           const y = Math.random() * (canvas.height - size * 2);
           const dx = (Math.random() - 0.5) * 4;
          const dy = (Math.random() - 0.5) * 4;
            const color = '#' + Math.floor(Math.random() * 16777215).toString(16);
          const type = types[Math.floor(Math.random() * types.length)];
            const styleName = styles[Math.floor(Math.random() * styles.length)]; // Choose a random style
           const style = shapeStyles[styleName];
         shapes.push(new Shape(x, y, dx, dy, size, color, type, style));
        }

     // Variables for tracking time for FPS calculation
    let lastFrameTime = performance.now();
    let frameCount = 0;

     function calculateFPS() {
           // Calculate FPS based on the time between frames
            const currentTime = performance.now();
           frameCount++;
          const elapsed = currentTime - lastFrameTime;

           if (elapsed >= 1000) {
                stats.fps.textContent = `FPS: ${frameCount}`;
                frameCount = 0;
             lastFrameTime = currentTime;
           }
      }

     function animate() {
         // Clear canvas
            ctx.clearRect(0, 0, canvas.width, canvas.height);

            // Loop through all shapes to move them, draw them and detect collisions
            shapes.forEach((shape, index) => {
               shape.move(); // Update the position
               shape.draw(); // Draw the shape

                shapes.forEach((other, otherIndex) => {
                // Collision detection and color change
                    if (index!== otherIndex && shape.checkCollision(other)) {
                        shape.collisions++;
                       shape.color = '#' + Math.floor(Math.random() * 16777215).toString(16);
                       if (shape.collisions >= 3) {
                          shapes.splice(index, 1);
                      }
                  }
                });
            });

             stats.remainingShapes.textContent = `Remaining Shapes: ${shapes.length}`;
             calculateFPS(); // Update the FPS counter

          requestAnimationFrame(animate); // Request a new frame for animation
      }

        animate(); // Start animation loop
});